@extends('layouts.template')

@section('titulo', 'Página Categorias - Listagens')

@section('conteudo')

    <h2>Página Categorias - Criação</h2>

@endsection