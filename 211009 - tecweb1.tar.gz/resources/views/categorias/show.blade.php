@extends('layouts.template')

@section('titulo', 'Página categorias - Mostrar')

@section('conteudo')
    <h2>Página Categorias - Mostrar</h2>
@endsection