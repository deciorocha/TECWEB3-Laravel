<?php $__env->startSection('titulo', 'Página Categorias - Listagens'); ?>

<?php $__env->startSection('conteudo'); ?>

    <h2>Página Categorias - Listagens</h2>


    <table class="table table-striped">
        <tr>
            <th>ID</th>
            <th>NOME</th>
        </tr>
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($categoria->id); ?></td>
                <td><?php echo e($categoria->nome); ?></td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div>
        <?php echo e($categorias->links()); ?>

    </div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deciorocha/htdocs/tecweb1/resources/views/categorias/index.blade.php ENDPATH**/ ?>