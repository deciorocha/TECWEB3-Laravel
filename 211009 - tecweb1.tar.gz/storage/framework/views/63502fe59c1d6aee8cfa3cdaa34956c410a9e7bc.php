<?php $__env->startSection('titulo', 'Produtos - Deletar'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container">
    <div class="card bg-light mb-3">
        <div class="card-body">
            <h5 class="card-title fs-2">Produtos - Editar</h5>
        </div>
    </div>

    <form action="<?php echo e(route('produtos.editar', $produto)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" class="form-control" id="nome" name="nome" value="<?php echo e($produto->nome); ?>">
        </div>
        <div class="mb-3">
            <label for="valor" class="form-label">Valor</label>
            <input type="text" class="form-control" id="valor" name="valor" value="<?php echo e($produto->valor); ?>">
        </div>
        <div class="mb-3">
            <label for="descricao" class="form-label">Descrição</label>
            <textarea class="form-control" name="descricao" id="descricao" rows="3"><?php echo e($produto->descricao); ?></textarea>
        </div>
        <a href="<?php echo e(route('produtos')); ?>" class="btn btn-success">Voltar</a>
        <button type="submit" name="salvar" class="btn btn-primary">Salvar</button>
    </form>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deciorocha/htdocs/tecweb1/resources/views/produtos/edit.blade.php ENDPATH**/ ?>