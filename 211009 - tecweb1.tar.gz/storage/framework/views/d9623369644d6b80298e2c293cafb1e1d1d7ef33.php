<?php $__env->startSection('titulo', 'Página Produtos - Criação'); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="card bg-light mb-3">
    <div class="card-body">
      <h5 class="card-title fs-2">Produtos - Cadastrar</h5>

    </div>
  </div>
    <h2></h2>
    <div class="container">
        <form method="POST" action="<?php echo e(route('produtos.inserir')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="nome" class="form-label">Nome:</label>
              <input type="text" class="form-control" name="nome" id="nome">
            </div>
            <div class="mb-3">
                <label for="valor" class="form-label">Valor:</label>
               <input type="text" class="form-control" name="valor" id="valor">
              </div>
              <div class="mb-3">
                <label for="descricao" class="form-label">Descrição:</label>
                <textarea class="form-control" name="descricao" id="descricao" rows="3"></textarea>
              </div>
            <a href="<?php echo e(route('produtos')); ?>" class="btn btn-success">Voltar</a>
            <button type="submit" name="salvar" class="btn btn-primary">Salvar</button>
          </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deciorocha/htdocs/tecweb1/resources/views/produtos/create.blade.php ENDPATH**/ ?>