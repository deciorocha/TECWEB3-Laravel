<?php $__env->startSection('titulo', 'Página Produtos - Apresentação'); ?>

<?php $__env->startSection('conteudo'); ?>
    <h1>Página Produtos - Apresentação</h1>
    
      <div class="card mt-3" style="width: 18rem;">
        <div class="card-header fw-bold text-center text-muted">
            <?= $produto->id ?>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item fw-bold text-muted"><?= $produto->nome ?></li>
          <li class="list-group-item text-muted"><?= $produto->descricao ?></li>
          <li class="list-group-item text-end text-muted"><?= $produto->valor ?></li>
        </ul>
        <a href="<?php echo e(route('produtos')); ?>" class="btn btn-primary"><i class="fas fa-undo"></i></a>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deciorocha/htdocs/tecweb1/resources/views/produtos/show.blade.php ENDPATH**/ ?>