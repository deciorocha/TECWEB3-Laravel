<?php $__env->startSection('titulo', 'Produtos - Deletar'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="container">
    <div class="card bg-light mb-3">
        <div class="card-body">
            <h5 class="card-title fs-2">Produtos - Excluir</h5>
        </div>
    </div>

    <form action="<?php echo e(route('produtos.deletar', $produto)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <div class="mb-3">
            <label for="nome" class="form-label">
                Deseja excluir o produto <b><?php echo e($produto->nome); ?></b>?
            </label>
            
        </div>
        <a href="<?php echo e(route('produtos')); ?>" class="btn btn-success">Voltar</a>
        <button type="submit" name="excluir" class="btn btn-primary">Excluir</button>
    </form>
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deciorocha/htdocs/tecweb1/resources/views/produtos/delete.blade.php ENDPATH**/ ?>