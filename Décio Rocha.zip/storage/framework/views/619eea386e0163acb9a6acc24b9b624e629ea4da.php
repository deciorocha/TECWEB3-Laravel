<?php $__env->startSection('titulo', 'Página Produtos - Listagens'); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="card bg-light mb-3">
    <div class="card-body">
      <h5 class="card-title fs-2">Produtos - Listagens</h5>
      <a href="<?php echo e(route('produtos.inserir')); ?>" class="btn btn-success">Cadastrar</a>
    </div>
  </div>
    <h2></h2>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th><button>ID</button></th>
                <th>NOME</th>
                <th>DESCRIÇÃO</th>
                <th>VALOR</th>
                <th>STATUS</th>
                <th>VER</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($produto->id); ?></td>
                <td><?php echo e($produto->nome); ?></td>
                <td><?php echo e($produto->descricao); ?></td>
                <td><?php echo e($produto->valor); ?></td>
                <td><input type="checkbox" name="status" value="1"></td>
                <td>
                    <a href="<?php echo e(route('produtos.ver', $produto->id)); ?>">
                        <button type="button" class="btn btn-primary btn-sm">
                            <i class="far fa-eye"></i>
                        </button>
                    </a>
                    <a href="<?php echo e(route('produtos.edit', $produto)); ?>">
                        <button type="button" class="btn btn-warning btn-sm">
                            <i class="far fa-edit"></i>
                        </button>
                    </a>
                    <a href="<?php echo e(route('produtos.delete', $produto->id)); ?>">
                        <button type="button" class="btn btn-danger btn-sm">
                            <i class="far fa-trash-alt"></i>
                        </button>
                    </a>
                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div>
        <?php echo e($produtos->links()); ?>

    </div> 
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deciorocha/htdocs/tecweb1/resources/views/produtos/index.blade.php ENDPATH**/ ?>