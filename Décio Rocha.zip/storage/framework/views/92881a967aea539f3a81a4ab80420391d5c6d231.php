<?php $__env->startSection('titulo', 'Meu Exemplo de template'); ?>

<?php $__env->startSection('conteudo'); ?>

Conteudo da minha Home.
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi quo sequi at, dicta repellendus, enim praesentium, corrupti cupiditate debitis ab eligendi maiores alias aliquid officiis vero. Aspernatur provident corrupti neque?</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto quia reprehenderit harum molestiae tenetur similique, qui tempora obcaecati inventore expedita cum delectus fugiat est, dolores eligendi libero exercitationem. Quis, aliquam.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deciorocha/htdocs/tecweb1/resources/views/home.blade.php ENDPATH**/ ?>